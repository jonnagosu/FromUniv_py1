arrlist = list()

for i in range(1,11):
    arrlist.append(i*2)
    # .append는 변수 배정하는 걸로 추정

print(arrlist)