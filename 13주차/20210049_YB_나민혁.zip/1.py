btslist = ['RM', '진', '슈가', '제이홉', '지민', '뷔', '정국']
bplist = ['지수', '제니', '로제', '리사']
njlist = []
njlist.append('민지')
njlist.append('다니엘')
njlist.append('해린')
njlist.append('혜인')
njlist.append('하니') 

print('-'*5, 'BTS', '-'*5)
for idolname in btslist:
    print(idolname)
    
print('-'*5, '블랙핑크', '-'*5)
for idolname in bplist:
    print(idolname)

print('-'*5, '뉴진스', '-'*5)
for idolname in njlist:
    print(idolname)

print(btslist)
print(bplist)
print(njlist)